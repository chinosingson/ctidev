# Changelog

## v0.2.0 (not yet released)

- jQuery API and events


## v0.1.0 (2014-09-12)

- first beta release
