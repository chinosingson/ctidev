PHP-Database-GeoJSON
====================

A collection of PHP scripts to query a database table or view and return the results in GeoJSON format, suitable for use in OpenLayers, Leaflet, etc.