Master Login System  
===================  
  
An advanced login system build upon bootstrap with features like  
- password recovery  
- privacy settings  
- admin panel  
- user profile  
- groups system (member, moderator, administrator and your custom one)  
- contact form  
- member list  

Video Walkthrough  
http://www.youtube.com/watch?v=y7SdQfZfLbA


== Install ==  

1. Upload the files to your server  
2. Run /install.php in your browser and complete the form  
3. Done !!


== ScreenShoots ==  

http://puu.sh/3gtZd.png - users list  
http://puu.sh/34xRK.png - login form  
http://puu.sh/34ytf.png - index page  
http://puu.sh/34yuS.png - register form  

Donate 
-----------------
If you like my code you can support me by making a [donation](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=5VVJJXVFMQ9ZN)
